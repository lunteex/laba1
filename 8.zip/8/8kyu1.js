function removeEveryOther(arr){
    return arr.filter((item, index) => index % 2 === 0);
  }